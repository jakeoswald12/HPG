const express = require('express');
const fs = require('fs');
const path = require('path');
const https = require('https');
const csv = require('csv-parser');
const { createObjectCsvWriter } = require('csv-writer');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Path to the CRM CSV — defaults to the bundled copy, but can be overridden
const CSV_PATH = process.env.CRM_CSV || path.join(__dirname, 'customers.csv');
const CSV_HEADERS = ['Last Name','First Name','Business','Address','City','State','Zip','Phone','Miscellaneous'];

// In-memory list of checked-in buyers for this sale session
let checkedInBuyers = [];
let nextBuyerNumber = 101;

// Google Apps Script web app URL (set via env or config)
let sheetsWebAppUrl = process.env.SHEETS_URL || 'https://script.google.com/macros/s/AKfycbz8BjPxtIr_YlUQA9nOSKfMQxZnfvfT8y3T5r0wUuwXbJHyjeyQc0sM4jaLAAluL4lo/exec';

// ─── CSV helpers ─────────────────────────────────────────────

function readCustomers() {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(CSV_PATH)) {
      return resolve([]);
    }
    const results = [];
    fs.createReadStream(CSV_PATH)
      .pipe(csv({
        headers: CSV_HEADERS,
        skipLines: 1,        // skip header row
        mapValues: ({ value }) => (value || '').trim()
      }))
      .on('data', (row) => {
        // Add a row index so we can update by position
        row._index = results.length;
        results.push(row);
      })
      .on('end', () => resolve(results))
      .on('error', reject);
  });
}

async function writeCustomers(customers) {
  const writer = createObjectCsvWriter({
    path: CSV_PATH,
    header: CSV_HEADERS.map(h => ({ id: h, title: h }))
  });
  // Strip internal fields
  const clean = customers.map(c => {
    const row = {};
    CSV_HEADERS.forEach(h => { row[h] = c[h] || ''; });
    return row;
  });
  await writer.writeRecords(clean);
}

// ─── API routes ──────────────────────────────────────────────

// Search by first and/or last name (case-insensitive, partial match)
app.get('/api/customers/search', async (req, res) => {
  try {
    const { first, last } = req.query;
    if (!first && !last) return res.json([]);

    const customers = await readCustomers();
    const results = customers.filter(c => {
      const firstMatch = !first || c['First Name'].toLowerCase().includes(first.toLowerCase());
      const lastMatch = !last || c['Last Name'].toLowerCase().includes(last.toLowerCase());
      return firstMatch && lastMatch;
    });
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update a customer by their CSV row index
app.put('/api/customers/:index', async (req, res) => {
  try {
    const idx = parseInt(req.params.index);
    const customers = await readCustomers();
    if (idx < 0 || idx >= customers.length) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    // Update only the fields that were sent
    CSV_HEADERS.forEach(h => {
      if (req.body[h] !== undefined) {
        customers[idx][h] = req.body[h];
      }
    });
    await writeCustomers(customers);
    res.json(customers[idx]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a new customer to the CRM
app.post('/api/customers', async (req, res) => {
  try {
    const customers = await readCustomers();
    const newCustomer = {};
    CSV_HEADERS.forEach(h => { newCustomer[h] = req.body[h] || ''; });
    customers.push(newCustomer);
    await writeCustomers(customers);
    newCustomer._index = customers.length - 1;
    res.json(newCustomer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Check-in (assign buyer number) ─────────────────────────

app.post('/api/checkin', async (req, res) => {
  try {
    const data = req.body; // customer fields
    const buyerNum = nextBuyerNumber++;
    const buyer = {
      buyerNumber: buyerNum,
      lastName: data['Last Name'] || '',
      firstName: data['First Name'] || '',
      fullName: `${data['First Name'] || ''} ${data['Last Name'] || ''}`.trim(),
      address: data['Address'] || '',
      city: data['City'] || '',
      state: data['State'] || '',
      zip: data['Zip'] || '',
      phone: data['Phone'] || '',
      email: data['Email'] || ''
    };
    checkedInBuyers.push(buyer);
    res.json({ buyerNumber: buyerNum, buyer });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all checked-in buyers this session
app.get('/api/checkin/list', (req, res) => {
  res.json(checkedInBuyers);
});

// ─── Google Sheets config ────────────────────────────────────

app.post('/api/config/sheets-url', (req, res) => {
  sheetsWebAppUrl = req.body.url || '';
  res.json({ ok: true, url: sheetsWebAppUrl });
});

app.get('/api/config/sheets-url', (req, res) => {
  res.json({ url: sheetsWebAppUrl });
});

// Proxy write to Google Sheets (uses https module to handle redirects properly)
app.post('/api/sheets/write', (req, res) => {
  if (!sheetsWebAppUrl) {
    return res.status(400).json({ error: 'Google Sheets URL not configured' });
  }

  const payload = JSON.stringify(req.body);
  console.log('[Sheets] Writing buyer:', req.body.firstName, req.body.lastName);

  function postToUrl(url, data, redirectCount) {
    if (redirectCount > 5) {
      console.error('[Sheets] Too many redirects');
      return res.status(500).json({ error: 'Too many redirects' });
    }

    const parsed = new URL(url);
    const options = {
      hostname: parsed.hostname,
      path: parsed.pathname + parsed.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data)
      }
    };

    const request = https.request(options, (response) => {
      // Handle Google's 302 redirect
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
        console.log('[Sheets] Following redirect to:', response.headers.location);
        // Follow redirect with GET (Google Apps Script already processed the POST)
        https.get(response.headers.location, (getRes) => {
          let body = '';
          getRes.on('data', chunk => body += chunk);
          getRes.on('end', () => {
            console.log('[Sheets] Full response:', body);
            res.json({ ok: true, response: body });
          });
        }).on('error', (err) => {
          console.error('[Sheets] Redirect GET error:', err.message);
          res.status(500).json({ error: err.message });
        });
        return;
      }

      let body = '';
      response.on('data', chunk => body += chunk);
      response.on('end', () => {
        console.log('[Sheets] Response:', response.statusCode, body.substring(0, 200));
        res.json({ ok: true, response: body });
      });
    });

    request.on('error', (err) => {
      console.error('[Sheets] Request error:', err.message);
      res.status(500).json({ error: err.message });
    });

    request.write(data);
    request.end();
  }

  postToUrl(sheetsWebAppUrl, payload, 0);
});

// ─── Start ───────────────────────────────────────────────────

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════════════╗');
  console.log('  ║       Bull Sale Check-In System              ║');
  console.log('  ╚══════════════════════════════════════════════╝');
  console.log('');
  console.log(`  Server running at http://localhost:${PORT}`);
  console.log(`  Operator screen:  http://localhost:${PORT}/operator.html`);
  console.log(`  Customer screen:  http://localhost:${PORT}/customer.html`);
  console.log('');
  console.log(`  CRM file: ${CSV_PATH}`);
  console.log(`  ${checkedInBuyers.length} buyers checked in this session`);
  console.log('');
});
